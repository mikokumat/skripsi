
<div class="halaman">
	<h2>SLUM AREA RANKING</h2>
	<p>INPUT BASED DSS SYSTEM</p>
</div>

<style>
.grid-container {
  display: grid;
  grid-template-columns: auto auto auto auto auto auto auto;
  background-color: #2196F3;
  padding: 10px;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  -ms-flex-align: center;
  align-items: center;
  -ms-flex-pack: justify;
  justify-content: space-between;
}
.grid-item {
  background-color: rgba(255, 255, 255, 0.8);
  border: 1px solid rgba(0, 0, 0, 0.8);
  padding: 10px;
  font-size: 18px;
  text-align: center;
}

.btn {
  display: inline-block;
  font-weight: 400;
  color: #212529;
  text-align: center;
  vertical-align: middle;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  background-color: transparent;
  border: 1px solid transparent;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.btn-primary {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
  margin-top:  10px;
}


</style>
</head>

<body>


<div class="grid-container">

  <div class="grid-item">Aspek 1 <br>
    <input type="text" name="aspekkriteria"><br></div>
  <div class="grid-item">Aspek 2 <br>
    <input type="text" name="aspekkriteria"><br></div>
  <div class="grid-item">Aspek 3 <br>
    <input type="text" name="aspekkriteria"><br></div>  
  <div class="grid-item">Aspek 4 <br>
    <input type="text" name="aspekkriteria"><br></div>
  <div class="grid-item">Aspek 5 <br>
    <input type="text" name="aspekkriteria"><br></div>
  <div class="grid-item">Aspek 6 <br>
    <input type="text" name="aspekkriteria"><br></div>  
  <div class="grid-item">Aspek 7 <br>
    <input type="text" name="aspekkriteria"><br></div>


  <div class="grid-item">Bobot <br>
  <input type="text" name="bobotkriteria"><br></div>
  <div class="grid-item">Bobot <br>
  <input type="text" name="bobotkriteria"><br></div>
   <div class="grid-item">Bobot <br>
  <input type="text" name="bobotkriteria"><br></div>  
   <div class="grid-item">Bobot <br>
  <input type="text" name="bobotkriteria"><br></div>  
   <div class="grid-item">Bobot <br>
  <input type="text" name="bobotkriteria"><br></div>  
   <div class="grid-item">Bobot <br>
  <input type="text" name="bobotkriteria"><br></div>  
   <div class="grid-item">Bobot <br>
  <input type="text" name="bobotkriteria"><br></div>


  <div class="grid-item">Atribut <br>
  <input type="text" name="atribut"><br></div>
  <div class="grid-item">Atribut <br>
  <input type="text" name="atribut"><br></div>
  <div class="grid-item">Atribut <br>
  <input type="text" name="atribut"><br></div>
  <div class="grid-item">Atribut <br>
  <input type="text" name="atribut"><br></div>
  <div class="grid-item">Atribut <br>
  <input type="text" name="atribut"><br></div>
  <div class="grid-item">Atribut <br>
  <input type="text" name="atribut"><br></div>
  <div class="grid-item">Atribut <br>
  <input type="text" name="atribut"><br></div>


  <div class="grid-item">Jumlah Sub Aspek<br>
  <input type="text" name="jumlahsub"><br></div>
  <div class="grid-item">Jumlah Sub Aspek<br>
  <input type="text" name="jumlahsub"><br></div>
  <div class="grid-item">Jumlah Sub Aspek<br>
  <input type="text" name="jumlahsub"><br></div>
  <div class="grid-item">Jumlah Sub Aspek<br>
  <input type="text" name="jumlahsub"><br></div>
  <div class="grid-item">Jumlah Sub Aspek<br>
  <input type="text" name="jumlahsub"><br></div>
  <div class="grid-item">Jumlah Sub Aspek<br>
  <input type="text" name="jumlahsub"><br></div>
  <div class="grid-item">Jumlah Sub Aspek<br>
  <input type="text" name="jumlahsub"><br></div>


</div>

<button type="button" class="btn btn-primary">Primary</button>
<!-- <form>
  Aspek :<br>
  <input type="text" name="aspekkriteria"><br>
  Bobot :<br>
  <input type="text" name="bobotkriteria"><br>
  Atribut :<br>
  <input type="text" name="atribut"><br>
  Jumlah Sub Aspek :<br>
  <input type="text" name="jumlahsub"><br>
  <input type="submit" value="Submit">
</form> -->
